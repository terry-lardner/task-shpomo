(function() {	

	$('#nav-menu').removeClass('hide');

	//init dropit
	$('.menu').dropit();
}());